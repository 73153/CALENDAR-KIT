INOYearCalendar
===============

An example of iOS - like year calendar with additional events display support

We also have a great app that we are going to publish soon. Join us on http://dayberry.today.

![alt tag](https://github.com/Streetmage/INOYearCalendar/blob/master/preview.png)