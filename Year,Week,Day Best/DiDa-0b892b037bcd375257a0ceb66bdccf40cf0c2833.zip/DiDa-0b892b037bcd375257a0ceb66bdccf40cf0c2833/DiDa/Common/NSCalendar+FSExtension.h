//
//  NSCalendar+FSExtension.h
//  Pods
//
//  Created by Wenchao Ding on 12/3/15.
//
//

#import <Foundation/Foundation.h>

@interface NSCalendar (FSExtension)

+ (instancetype)fs_sharedCalendar;

@end
