//
//  SettingsViewController.h
//  DiDa
//
//  Created by Bruce Yee on 4/3/15.
//  Copyright (c) 2015 Bruce Yee. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingsViewController : UIViewController {
    __weak IBOutlet UIButton *setupButton;
    __weak IBOutlet UIButton *offButton;
    __weak IBOutlet UIButton *aboutButton;
}

@end
